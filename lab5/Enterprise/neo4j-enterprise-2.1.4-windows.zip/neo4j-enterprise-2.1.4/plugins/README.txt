Neo4j Plugins
=======================================

Plugins are like server-side scripts that can add functions for
retrieving nodes, relationships, paths or properties.

When packaged as a jar, just drop the plugin into this directory
before starting up the server. 

